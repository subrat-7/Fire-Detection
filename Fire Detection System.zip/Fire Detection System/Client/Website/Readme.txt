Instructions to launch the website


Step 1 : Setup the Xampp server

Step 2: Save the given folder in the htdoc folder in the xampp folder

Step 3: import the sql file from the given database folder to the mysql admin configuration

Step : 4 open chrome and type localhost/foldername