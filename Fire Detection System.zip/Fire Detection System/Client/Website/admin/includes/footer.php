 <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                    <a class="btn btn-primary" href="https://console.firebase.google.com/project/fire-1c516/storage/fire-1c516.appspot.com/files">Auto Reportings</a>
                <a class="btn btn-primary" href="#">Raise Token</a>
                        <span>Copyright &copy; <?php echo $wtitle;?> </span>
                     
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->